import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
import datetime

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def run():
    """Show portfolio of stocks"""
    user_id = session["user_id"]

    stocks = db.execute("SELECT symbol, shares FROM user_stocks WHERE user_id = ?", user_id)
    stock_prices = {}
    total_value = 0


    for stock in stocks:
        if stock['shares'] == 0:
            db.execute("DELETE FROM user_stocks WHERE symbol = ? AND user_id = ?",
                       stock['symbol'], user_id)

            continue

        value = lookup(stock['symbol'])

        if value:
            stock_prices[stock['symbol']] = value['price']
            shares = stock['shares']
            stock['total_value'] = stock_prices[stock['symbol']] * stock['shares']

    return render_template("index.html", stocks=stocks, stock_prices=stock_prices, total_value = total_value)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":
        user_id = session["user_id"]
        stock = request.form.get("symbol")
        numberofshares = request.form.get("shares")

        try:
            number_of_shares = int(numberofshares)
            if number_of_shares <= 0:
                return apology("invalid number of shares")
        except ValueError:
            return apology("invalid number of shares")

        if not stock.isalpha():
            return apology("invalid stock symbol")

        elif stock:
            values = lookup(stock)

            if not values:
                return apology("Symbol not found")

            try:
                symbol = values['symbol']
                price = values['price']
            except Exception as e:
                return apology(e)
        else:
            return apology("missing stock symbol")

        if not number_of_shares or number_of_shares <= 0:
            return apology("invalid number of shares")

        cost = price * int(number_of_shares)
        current_cash_list = db.execute("SELECT cash FROM users WHERE id = ?", user_id)
        current_cash = current_cash_list[0]["cash"]

        if current_cash < cost:
            return apology("Not enough cash")

        user_stocks = db.execute(
            "SELECT shares FROM  user_stocks WHERE user_id = ? AND symbol = ?", user_id, symbol)
        if not user_stocks:
            db.execute("INSERT INTO user_stocks (user_id, symbol, shares) VALUES (?, ?, ?)",
                       user_id, symbol, number_of_shares)

        if user_stocks:
            current_shares = user_stocks[0]["shares"]
            db.execute("UPDATE user_stocks SET shares = ? WHERE user_id = ? AND symbol = ?",
                       current_shares + number_of_shares, user_id, symbol)

        db.execute("UPDATE users SET cash = ? WHERE id = ?", current_cash - cost, user_id)

        date = datetime.datetime.now()
        db.execute("INSERT INTO transactions (user_id, symbol, shares, buyorsell, date, pricee) VALUES (?, ?, ?, ?, ?, ?)",
                   user_id, symbol, number_of_shares, "buy", date, price)
        return redirect("/")

    return render_template("buy.html")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    user_id = session["user_id"]

    transactions = db.execute(
        "SELECT symbol, shares, buyorsell, date, pricee FROM transactions WHERE user_id = ?", user_id)

    return render_template("history.html", transactions=transactions)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "POST":
        symbol = request.form.get("symbol")
        if not symbol.isalpha():
            return apology("invalid stock symbol")
        values = lookup(symbol)

        if not values:
            return apology("Symbol not found")


        return render_template("quotes.html", name=values["name"], symbol=values["symbol"], price=values["price"])

    return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "POST":
        username = request.form .get("username")
        password = request.form.get("password")
        confirm = request.form.get("confirmation")
        if not username or not password or not confirm:
            return apology("No input")

        username = username.strip()

        if password != confirm:
            return apology("passwords do not match")

        checkuser = db.execute("SELECT username FROM users WHERE username = ?", username)

        if checkuser:
            return apology("Username already exists")
        else:
            try:
                hashed_password = generate_password_hash(password)
                db.execute("INSERT INTO users (username, hash) VALUES (?, ?)",
                           username, hashed_password)
            except Exception:
                return apology("An Error Has occured")

    return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    user_id = session["user_id"]

    if request.method == "POST":
        user_id = session["user_id"]

        symbol = request.form.get("symbol")
        if not symbol.isalpha():
            return apology("invalid stock symbol")

        shares = int(request.form.get("shares"))
        if not shares:
            return apology("missing shares")

        shares_owned_result = db.execute(
            "SELECT shares FROM user_stocks WHERE user_id = ? AND symbol = ?", user_id, symbol)
        shares_owned = shares_owned_result[0]['shares'] if shares_owned_result else 0

        cash_list = db.execute("SELECT cash FROM users WHERE id = ?", user_id)
        cash = cash_list[0]['cash']

        values = lookup(symbol)
        print(f"symbol: {symbol} shares: {shares} shares_owned: {shares_owned}")

        if not values:
            return apology("Symbol not found")

        price = values['price']

        if shares_owned >= shares:
            db.execute("UPDATE user_stocks SET shares = ? WHERE user_id = ? AND symbol = ?",
                       shares_owned-shares, user_id, symbol)
            db.execute("UPDATE users SET cash = ? WHERE id = ?",
                       cash + (values['price']*shares), user_id)
            print("check")
            date = datetime.datetime.now()
            db.execute("INSERT INTO transactions (user_id, symbol, shares, buyorsell, date, pricee) VALUES (?, ?, ?, ?, ?, ?)",
                       user_id, symbol, shares, "sell", date, price)
            return render_template("sell.html")
        elif shares_owned <= shares:
            return apology("You don't have enough of this stock")

        else:
            return apology("Something went wrong")

    return render_template("sell.html")


@app.route("/change_password", methods=["GET", "POST"])
def change_password():

    if request.method == "POST":
        password = request.form.get("password")
        confirm = request.form.get("confirmation")

        user_id = session["user_id"]

        if password != confirm:
            return apology("passwords do not match")

        try:
            hashed_password = generate_password_hash(password)
            db.execute("UPDATE users SET hash = ? WHERE id = ?", hashed_password, user_id)
        except Exception:
            return apology("An Error Has occured")

    return render_template("change_password.html")
